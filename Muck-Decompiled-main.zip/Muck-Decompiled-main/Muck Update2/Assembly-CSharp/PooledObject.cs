﻿// Decompiled with JetBrains decompiler
// Type: PooledObject
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 68ECCA8E-CF88-4CE2-9D74-1A5BFC0637BB
// Assembly location: D:\Repo\Muck Update2\Assembly-CSharp.dll

using UnityEngine;

public class PooledObject
{
  public int id;
  public int hp;
  public Vector3 position;
  public Vector3 scale;
  public Quaternion rotation;
  public int prefabType;
  public int idInPool;
  public int poolId;
  public bool activeInPool;
}
