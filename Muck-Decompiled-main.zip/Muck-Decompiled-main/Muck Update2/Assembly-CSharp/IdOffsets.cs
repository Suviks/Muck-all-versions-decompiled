﻿// Decompiled with JetBrains decompiler
// Type: IdOffsets
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 68ECCA8E-CF88-4CE2-9D74-1A5BFC0637BB
// Assembly location: D:\Repo\Muck Update2\Assembly-CSharp.dll

using UnityEngine;

public class IdOffsets
{
  public static Vector2 treeIdOffset = new Vector2(0.0f, 1999f);
  public static Vector2 rockIdOffset = new Vector2(2000f, 2999f);
  public static Vector2 p_rockIdOffset = new Vector2(5000f, 5499f);
  public static Vector2 p_branchIdOffset = new Vector2(5500f, 6000f);
  public static Vector2 buildIdRange = new Vector2(20000f, 30000f);
  public static Vector2 chestIdRange = new Vector2(10000f, 12000f);
}
